import streamlit as st
import boto3
import json

st.set_page_config(page_title="Claude Chat (Bedrock)", layout="centered")
st.title("🧠 Claude Chat (Amazon Bedrock)")
st.markdown("与你的 Claude 模型对话，使用你的 AWS Bedrock Access Key。")

with st.sidebar:
    st.header("🔐 AWS 凭证配置")
    access_key = st.text_input("AWS_ACCESS_KEY_ID", type="password")
    secret_key = st.text_input("AWS_SECRET_ACCESS_KEY", type="password")
    region = st.text_input("Region（如 us-east-1）", value="us-east-1")
    list_models = st.button("获取可用模型")

# 存储状态
if "models" not in st.session_state:
    st.session_state.models = []
if "client" not in st.session_state:
    st.session_state.client = None
if "llm_ready" not in st.session_state:
    st.session_state.llm_ready = False
if "messages" not in st.session_state:
    st.session_state.messages = []

# 获取模型列表
if list_models and access_key and secret_key and region:
    try:
        client = boto3.client(
            "bedrock",
            region_name=region,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
        )
        response = client.list_foundation_models()
        models = [m["modelId"] for m in response["modelSummaries"] if m["providerName"] == "Anthropic"]
        st.session_state.models = sorted(models)
        st.session_state.client = boto3.client(
            "bedrock-runtime",
            region_name=region,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
        )
        st.success("✅ 成功获取模型列表！请选择模型后开始聊天。")
    except Exception as e:
        st.error(f"❌ 获取失败: {e}")

# 模型选择
if st.session_state.models:
    model_id = st.selectbox("请选择 Claude 模型", st.session_state.models)
    init_chat = st.button("✅ 初始化 Claude 聊天")
else:
    model_id = None
    init_chat = False

# 初始化聊天
if init_chat and model_id:
    st.session_state.model_id = model_id
    st.session_state.llm_ready = True
    st.success(f"✅ Claude 模型已就绪: {model_id}")

# 聊天输入
if st.session_state.llm_ready:
    user_input = st.chat_input("输入你的问题...")
    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})
        with st.spinner("Claude 正在生成回答..."):
            try:
                payload = {
                    "prompt": f"\n\nHuman: {user_input}\n\nAssistant:",
                    "max_tokens_to_sample": 500
                }
                response = st.session_state.client.invoke_model(
                    modelId=st.session_state.model_id,
                    body=json.dumps(payload),
                    contentType="application/json",
                    accept="application/json"
                )
                result = response["body"].read().decode()
                st.session_state.messages.append({"role": "assistant", "content": result})
            except Exception as e:
                st.session_state.messages.append({"role": "assistant", "content": f"❌ Claude 错误: {e}"})

# 聊天展示
for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.chat_message("user").write(msg["content"])
    else:
        st.chat_message("assistant").write(msg["content"])
