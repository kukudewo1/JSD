#!/bin/bash
set -e

echo "📦 安装依赖"
sudo apt update
sudo apt install -y python3 python3-pip python3-venv sqlite3 unzip

echo "📁 创建项目目录"
mkdir -p ~/shortlink_project/templates
cd ~/shortlink_project

echo "🐍 创建虚拟环境"
python3 -m venv venv
source venv/bin/activate

echo "📦 安装 Python 库"
pip install flask requests

echo "✅ 运行服务"
nohup venv/bin/python3 app.py > flask.log 2>&1 &
echo "🚀 服务已启动: http://<你的服务器IP>:5000/"
