from flask import Flask, request, render_template, redirect
import sqlite3
import string
import random
import requests
from datetime import datetime

app = Flask(__name__)
DB_PATH = 'links.db'

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                type TEXT,
                episode TEXT,
                short_code TEXT UNIQUE,
                original_url TEXT,
                created_at TEXT
            )
        ''')
init_db()

def generate_short_code(length=6):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def resolve_final_url(initial_url):
    try:
        response = requests.get(initial_url, allow_redirects=False, timeout=5)
        if 'Location' in response.headers:
            return response.headers['Location']
    except Exception as e:
        print(f"[解析失败] {e}")
    return None

@app.route('/')
def index():
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT id, name, type, episode, short_code, original_url, created_at FROM links ORDER BY id DESC')
        rows = cur.fetchall()
    return render_template('index.html', links=rows)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        name = request.form.get('name')
        type_ = request.form.get('type')
        episode = request.form.get('episode')
        original_url = request.form.get('url')
        if not resolve_final_url(original_url):
            return '解析失败，链接无效或不是mp4', 400
        short_code = generate_short_code()
        created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute('INSERT INTO links (name, type, episode, short_code, original_url, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                         (name, type_, episode, short_code, original_url, created_at))
            conn.commit()
        return render_template('success.html', short_code=short_code)
    return render_template('add.html')

@app.route('/delete/<int:link_id>')
def delete(link_id):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('DELETE FROM links WHERE id = ?', (link_id,))
        conn.commit()
    return redirect('/')

@app.route('/<short_code>')
def get_final_link(short_code):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT original_url FROM links WHERE short_code = ?', (short_code,))
        row = cur.fetchone()
        if row:
            final_url = resolve_final_url(row[0])
            if final_url:
                return redirect(final_url, code=302)
    return '无效链接或解析失败', 404

@app.route('/play/<short_code>')
def play_video(short_code):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT original_url FROM links WHERE short_code = ?', (short_code,))
        row = cur.fetchone()
        if row:
            video_url = resolve_final_url(row[0])
            if video_url:
                return render_template('play.html', video_url=video_url)
    return '无法解析视频链接', 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, use_reloader=False)
