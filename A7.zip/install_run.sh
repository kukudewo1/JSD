#!/bin/bash
set -e
sudo apt-get update
sudo apt-get install -y python3 python3-pip unzip wget
WORKDIR=~/realtime_link_app
mkdir -p $WORKDIR
cd $WORKDIR
cp "$(dirname "$0")"/A1_realtime.zip $WORKDIR/A1_realtime.zip 2>/dev/null || true
unzip -o A1_realtime.zip || unzip -o ../A1_realtime.zip || true
if [ -f requirements.txt ]; then
    pip3 install --upgrade pip
    pip3 install -r requirements.txt
fi
sudo ufw allow 5000/tcp || true
nohup python3 app.py > flask.log 2>&1 &
echo "服务已启动，访问 http://服务器IP:5000/"
echo "如需停止服务：pkill -f 'python3 app.py'"
