#!/bin/bash
set -e
sudo apt-get update
sudo apt-get install -y python3 python3-pip python3-venv unzip wget
WORKDIR=~/final_ui_perfect
mkdir -p $WORKDIR
cd $WORKDIR
wget -O final_ui_perfect.zip "https://github.com/kukudewo1/JSD/raw/main/final_ui_perfect.zip" || cp "$(dirname "$0")"/final_ui_perfect.zip $WORKDIR/final_ui_perfect.zip 2>/dev/null || true
unzip -o final_ui_perfect.zip || unzip -o ../final_ui_perfect.zip || true
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
sudo ufw allow 5000/tcp || true
nohup python app.py > flask.log 2>&1 &
echo "服务已启动，访问 http://服务器IP:5000/"
echo "如需停止服务：pkill -f 'python app.py'"
