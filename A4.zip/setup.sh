#!/bin/bash
echo "🔧 正在安装依赖环境..."
apt update
apt install -y python3 python3-venv unzip

echo "📦 创建虚拟环境并安装依赖..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo "✅ 启动项目中..."
nohup python app.py > flask.log 2>&1 &

echo "🚀 部署完成！访问 http://<你的服务器IP>:5000/"
