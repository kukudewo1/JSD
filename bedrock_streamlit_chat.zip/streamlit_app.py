import streamlit as st
import boto3

st.set_page_config(page_title="Claude Chat (Amazon Bedrock)", layout="centered")

st.title("🧠 Claude Chat (Amazon Bedrock)")
st.markdown("与你的 Claude 模型对话，使用你的 AWS Bedrock Access Key。")

# 输入 AWS 凭证和模型配置
with st.sidebar:
    st.header("🔐 AWS 凭证配置")
    access_key = st.text_input("AWS_ACCESS_KEY_ID", type="password")
    secret_key = st.text_input("AWS_SECRET_ACCESS_KEY", type="password")
    region = st.text_input("Region（如 us-east-2）", value="us-east-2")
    model_id = st.text_input("模型 ID", value="anthropic.claude-v2")
    run = st.button("初始化模型")

# 保存会话状态
if "messages" not in st.session_state:
    st.session_state.messages = []

# 初始化 Bedrock 客户端
if run and access_key and secret_key:
    try:
        client = boto3.client(
            "bedrock-runtime",
            region_name=region,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
        )
        st.session_state.client = client
        st.session_state.model_id = model_id
        st.success("✅ 模型初始化成功，可以开始对话！")
    except Exception as e:
        st.error(f"初始化失败: {e}")

# 聊天输入框
if "client" in st.session_state:
    user_input = st.chat_input("输入你的问题...")
    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})

        with st.spinner("Claude 思考中..."):
            try:
                response = st.session_state.client.invoke_model(
                    modelId=st.session_state.model_id,
                    body=f'{{"prompt":"\n\nHuman: {user_input}\n\nAssistant:", "max_tokens_to_sample": 500}}',
                    contentType="application/json",
                    accept="application/json"
                )
                result = response["body"].read().decode()
                st.session_state.messages.append({"role": "assistant", "content": result})
            except Exception as e:
                st.session_state.messages.append({"role": "assistant", "content": f"❌ 错误: {e}"})

# 显示聊天历史
for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.chat_message("user").write(msg["content"])
    else:
        st.chat_message("assistant").write(msg["content"])
