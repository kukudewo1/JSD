from flask import Flask, request, redirect, render_template, url_for
import sqlite3
import string
import random
import requests
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

app = Flask(__name__)
DB_PATH = 'links.db'
executor = ThreadPoolExecutor(max_workers=5)

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                type TEXT,
                episode TEXT,
                short_code TEXT UNIQUE,
                resolved_url TEXT,
                created_at TEXT
            )
        """)

init_db()

def generate_short_code(length=6):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def resolve_final_url(initial_url):
    try:
        response = requests.get(initial_url, allow_redirects=False, timeout=5)
        if 'Location' in response.headers:
            final_url = response.headers['Location']
            if final_url.endswith('.mp4') or '.mp4' in final_url:
                return final_url
    except Exception as e:
        print(f"[解析失败] {e}")
    return None

@app.route('/')
def index():
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT id, name, type, episode, short_code, resolved_url, created_at FROM links ORDER BY id DESC')
        rows = cur.fetchall()
    return render_template('index.html', links=rows)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        name = request.form.get('name')
        type_ = request.form.get('type')
        episode = request.form.get('episode')
        original_url = request.form.get('url')
        resolved_url = resolve_final_url(original_url)
        if not resolved_url:
            return '解析失败，链接无效或不是mp4', 400
        short_code = generate_short_code()
        created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute('INSERT INTO links (name, type, episode, short_code, resolved_url, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                         (name, type_, episode, short_code, resolved_url, created_at))
            conn.commit()
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:link_id>', methods=['GET', 'POST'])
def edit(link_id):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT * FROM links WHERE id = ?', (link_id,))
        link = cur.fetchone()
        if not link:
            return '未找到该链接', 404

        if request.method == 'POST':
            name = request.form.get('name')
            type_ = request.form.get('type')
            episode = request.form.get('episode')
            original_url = request.form.get('url')
            resolved_url = resolve_final_url(original_url)
            if not resolved_url:
                return '解析失败', 400
            conn.execute('UPDATE links SET name=?, type=?, episode=?, resolved_url=?, created_at=? WHERE id=?',
                         (name, type_, episode, resolved_url, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), link_id))
            conn.commit()
            return redirect(url_for('index'))

    return render_template('edit.html', link=link)

@app.route('/delete/<int:link_id>')
def delete(link_id):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('DELETE FROM links WHERE id = ?', (link_id,))
        conn.commit()
    return redirect(url_for('index'))

@app.route('/<short_code>')
def redirect_short(short_code):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT resolved_url FROM links WHERE short_code = ?', (short_code,))
        row = cur.fetchone()
        if row:
            return redirect(row[0], code=302)
    return '无效链接', 404

@app.route('/play/<short_code>')
def play(short_code):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT resolved_url FROM links WHERE short_code = ?', (short_code,))
        row = cur.fetchone()
        if row:
            return render_template('play.html', video_url=row[0])
    return render_template('play.html', video_url=None)

@app.route('/raw/<short_code>')
def raw_url(short_code):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute('SELECT resolved_url FROM links WHERE short_code = ?', (short_code,))
        row = cur.fetchone()
        if row:
            return row[0], 200, {'Content-Type': 'text/plain'}
    return '未找到该链接', 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, use_reloader=False, debug=False)
